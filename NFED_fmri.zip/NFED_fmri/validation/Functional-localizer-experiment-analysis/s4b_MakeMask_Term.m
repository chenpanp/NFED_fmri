
%first modify FILE sub21_locate_transfer.sh
bash sub22_locate_transfer.sh