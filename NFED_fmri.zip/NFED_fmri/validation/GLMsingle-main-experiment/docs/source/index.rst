.. GLMsingle documentation master file, created by
   sphinx-quickstart on Sat Apr  9 11:02:56 2022.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to GLMsingle's documentation!
=====================================

.. toctree::
   :maxdepth: 1
   :caption: Contents:

   matlab
   python
   wiki

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
