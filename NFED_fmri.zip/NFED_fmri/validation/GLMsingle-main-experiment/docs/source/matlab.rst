MATLAB doc
**********

.. mat:automodule:: matlab

.. mat:autofunction:: GLMestimatesingletrial
