Python doc
**********

.. module:: glmsingle.glmsingle

.. autoclass:: GLM_single
   :members:
   :undoc-members:
   :show-inheritance:
