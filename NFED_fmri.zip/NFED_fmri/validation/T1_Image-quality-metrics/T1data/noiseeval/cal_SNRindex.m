clc
clear

addpath('/home/lcao/software/NIfTI_20140122');

path='/media/lcao/DATA/T1_structure/cpp/T1data/noiseeval/';
subj=textread(strcat(path,'sub.txt'),'%s');
filetype='.nii.gz';

SNR_index=zeros(5,4);
% the sequence of SNR_index is CJV, CNR, SNR_GM, SNR_WM

for i = 1:length(subj)
    bg=load_untouch_nii(strcat(path,'origindata/',subj{i},'_bg',filetype));
    bgimg=bg.img;
    bgid=find(bgimg~=0);
    bgvoxel_num=numel(bgid);
    bn=load_untouch_nii(strcat(path,'origindata/',subj{i},'_brain',filetype));
    bnimg=bn.img;
    gm_mask=load_untouch_nii(strcat(path,'segment/',subj{i},'_GMmask',filetype));
    gm_maskimg=gm_mask.img;
    wm_mask=load_untouch_nii(strcat(path,'segment/',subj{i},'_WMmask',filetype));
    wm_maskimg=wm_mask.img;
    gmid=find(gm_maskimg==1);
    gmvoxel_num=numel(gmid);
    wmid=find(wm_maskimg==1);
    wmvoxel_num=numel(wmid);
    CJV=(std(bnimg(gmid))+std(bnimg(wmid)))./abs(mean(bnimg(gmid))-mean(bnimg(wmid)));
    SNR_index(i,1)=CJV;
    CNR=abs(std(bnimg(gmid))-std(bnimg(wmid)))./std(bgimg(bgid));
    SNR_index(i,2)=CNR;
    SNR_GM=mean(bnimg(gmid))./std(bnimg(gmid));
    SNR_index(i,3)=SNR_GM;
    SNR_WM=mean(bnimg(wmid))./std(bnimg(wmid));
    SNR_index(i,4)=SNR_WM;
end
    
    
    