#!/bin/sh

path=/media/lcao/DATA/T1_structure/cpp

for file in `cat $path/cpp.txt`
do
	dcm2niix -z y -x y $path/$file
	cp $path/$file/*Crop* $path/$file/${file}.nii.gz
	gunzip $path/$file/${file}.nii.gz
done
