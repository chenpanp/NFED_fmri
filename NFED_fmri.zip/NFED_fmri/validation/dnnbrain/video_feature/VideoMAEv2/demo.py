import numpy as np
tmp = np.load("/root/autodl-tmp/datasets/Algonauts_2023/features/videoMAEV2/vit_g_hybrid_pt_1200e_k710_ft_1048/sub01/0001_00.npy")
print(tmp.shape)