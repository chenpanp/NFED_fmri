

def replace_infs_nans(array):
    array[np.isinf(array) | np.isnan(array)] = 0
    return array


data=h5py.File('G:/noise_celling_data/ZUIXINDATA/sub04_DATA/TEST_DATA/noise_celling_hebing/chongfuwumean/sub04_test_mean.mat', 'r')
dataset = data['averagedData']  # 根据数据集的名称获取数据集的引用
Y_test = dataset[:]



data0=h5py.File('G:/noise_celling_data/ZUIXINDATA/sub04_DATA/TEST_DATA/noise_celling_hebing/chongfumean/sub04_test_mean.mat')
dataset0 = data0['averagedData']
Y_test_avg=dataset0[:]




data1=h5py.File('G:/test_data_noise_celling/sub04/sub04_test_label.mat', 'r')
dataset_1 = data1['stim_label']  # 根据数据集的名称获取数据集的引用
label = dataset_1[:].astype(int)
labels = label.T.flatten()
labels = labels[labels < 100000]

 # 返回的值是 np.array(train_labels), np.array(test_labels)

# 计算信号的均值
mean_sig = np.mean(Y_test_avg, axis=0)

# 计算信号和噪声的方差
var_sig_noise = np.var(Y_test_avg, axis=0)  # 其中axis=0表示按列求方差，当axis=1表示按行求方差，未给出axis则表示将所有元素加起来求方差。

noise = 0

for l in labels:
    if l < 100000:
       noise += np.var(Y_test[labels == l], axis=0)

labels = labels[labels < 100000]
var_noise = noise / (len(labels) * 10)
var_signal = np.maximum(0, var_sig_noise - var_noise)

num_voxels =Y_test.shape[1]
noise_ceiling = np.zeros([num_voxels, ])

moni_1000 = np.zeros([100, 10])
for i in range(num_voxels):
    for m in range(100):  # 模拟信号100次
        moni_mean_sig = mean_sig[i]
        moni_std_sig = np.sqrt(var_signal[i])
        moni_signal = np.random.normal(moni_mean_sig, moni_std_sig, size=(120, ))
        for n in range(10):  # 模拟噪声(测量信号)10次
            moni_std_noise = np.sqrt(var_noise[i])
            moni_noise = np.random.normal(0, moni_std_noise, size=(120, ))
            moni_measurement = moni_signal + moni_noise

            moni_1000[m, n] = stats.pearsonr(moni_signal, moni_measurement)[0]

    noise_ceiling_nan = np.mean(moni_1000)
    noise_ceiling[i] = np.nan_to_num(noise_ceiling_nan)

np.save("G:/noise_ceiling_results/sub04/noise_ceiling_sub04_ts.npy", noise_ceiling)

w=np.mean(noise_ceiling)
print(w)

np.save("G:/noise_ceiling_results/sub04/noise_ceiling_sub04_ts_mean.npy", w)


# save_path = 'F:/TJ_20230917/noise_ceiling/noise_ceiling_S1_FFA-1.mat'
# io.savemat(save_path, {'noise_ceiling_S1_FFA-1': noise_ceiling})





