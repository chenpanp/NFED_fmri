import numpy as np
from scipy.stats import pearsonr
import h5py  # 导入 h5py 库来处理 HDF5 文件
from scipy.io import savemat

# 创建示例数据
N = 266484
num_runs = 60

# 初始化奇数和偶数的beta系列数组
beta_series_odd = np.zeros((N, 0))
beta_series_even = np.zeros((N, 0))

# 加载所有run的数据
for run in range(1, num_runs + 1):
    # 构造文件路径
    file_path = f"G:/noise_celling_data/ZUIXINDATA/sub05_DATA_beta/TRAIN_DATA/paixu/run{run:02d}.mat"

    # 使用 h5py 加载数据
    with h5py.File(file_path, 'r') as f:
        beta_series = f['Mean_Data'][:]
        beta_series = np.nan_to_num(beta_series, nan=0)
        beta_series = beta_series.T

    # 根据run的奇偶性将数据添加到相应的数组中
    if run % 2 == 1:  # 奇数run
        beta_series_odd = np.hstack((beta_series_odd, beta_series))
    else:  # 偶数run
        beta_series_even = np.hstack((beta_series_even, beta_series))

# 用于存储皮尔逊相关系数和 p 值的数组
correlation_results = np.zeros(N)
p_values = np.zeros(N)

# 计算每个顶点的皮尔逊相关系数
for vertex in range(N):
    correlation, p_value = pearsonr(beta_series_odd[vertex, :], beta_series_even[vertex, :])
    correlation_results[vertex] = correlation
    p_values[vertex] = p_value

# 保存结果
savemat("G:/ALLSUB_ROI_label/sub05/sub05_data/correlation_results.mat", {'correlation_results': correlation_results})
savemat("G:/ALLSUB_ROI_label/sub05/sub05_data/p_values.mat", {'p_values': p_values})