A large-scale fMRI dataset in response to short naturalistic facial expressions videos
# 1.We run run the program(data2bids.sh) to convert raw data files to the BIDS

# 2.We run run the program(s1_preprocess.m)  for volume-based preprocessing

# 3.We run run the program(s1_preprocess_alignment.m) to co-register the average of the pre-processed functional volumes obtained in a scan session to the T1 volume (rigid-body transformation).
